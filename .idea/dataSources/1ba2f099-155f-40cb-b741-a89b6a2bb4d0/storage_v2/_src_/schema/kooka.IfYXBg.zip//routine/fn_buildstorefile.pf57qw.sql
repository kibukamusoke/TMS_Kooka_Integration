create function fn_buildStoreFile()
  returns text
  BEGIN
    DECLARE output TEXT;


    DECLARE file_data TEXT DEFAULT '';

    SET @file_type = 6;
    SET @file_name = 'STORE.LST';
    SET @file_id = 1;

    SET @otherheaders = CONCAT('SCAN=1', CHAR(10),
                               'O_EN=Please select one ', CHAR(10),
                               'SEARCH_COL=2;6,1,LOCMAP.TXT;1,3', CHAR(10));


    SET file_data = CONCAT('-1|N/A|0|', CHAR(10));

    SELECT CONCAT(file_data, GROUP_CONCAT(rex SEPARATOR '
'), CHAR(10)) INTO file_data
    FROM (SELECT concat(container_do, '|', id, '|', container_do, '|0|') as rex
          FROM k_storeink
          WHERE status = 1
          GROUP BY container_do
          ORDER BY container_do ASC) X;

    SET @fd_data = CONCAT(
        'T=', hex(@file_type), CHAR(10),
        'I=', hex(@file_id), CHAR(10),
        'R=1', CHAR(10),
        'L=', @file_name, CHAR(10),
        'M=1', CHAR(10),
        @otherheaders,
        'D=', CHAR(10),
        COALESCE(file_data, ''));

    SET @datalength = LENGTH(@fd_data);

    SET output = CONCAT('B=', @datalength, CHAR(10), @fd_data);


    RETURN output;
  END;

