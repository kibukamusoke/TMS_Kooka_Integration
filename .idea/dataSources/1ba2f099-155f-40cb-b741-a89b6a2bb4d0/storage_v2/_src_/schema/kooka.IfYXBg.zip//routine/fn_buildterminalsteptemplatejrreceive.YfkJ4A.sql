create function fn_buildTerminalStepTemplateJrReceive()
  returns text
  BEGIN
    DECLARE output TEXT;

    DECLARE file_data TEXT DEFAULT '';

    SET @file_type = 7;
    SET @file_name = 'JRRCVE.DAT';
    SET @file_id = 1;

    SET @otherheaders = '';


    SET file_data = '{
   "id":"jr_receive",
   "form":{
      "title":"Jumbo Roll Details",
      "layout":[
         {
            "ctrl":"input",
            "id":"invoice_no",
            "label":"Invoice Number",
            "type":"string",
            "minlen":1,
            "maxlen":255,
            "keyin":null,
            "title":null
         },{
            "ctrl":"input",
            "id":"container_no",
            "label":"Container No",
            "type":"string",
            "minlen":1,
            "maxlen":255,
            "keyin":null,
            "title":null
         },
         {
            "ctrl":"input",
            "id":"stock_no",
            "label":"Stock Code",
            "type":"lbox",
            "def":{
               "t":"N/A",
               "k":"-1"
            },
            "dsrc":"6,=REF,POSTOCK.TXT",
            "nline":3
         },
         {
            "ctrl":"input",
            "id":"rolls_cnt",
            "label":"No. of Rolls",
            "type":"number",
            "minlen":1,
             "maxlen":255,
             "keyin":null,
             "title":null
         },
         {
            "ctrl":"input",
            "id":"total_weight",
            "label":"Total Weight",
            "type":"number",
            "minlen":1,
             "maxlen":255,
             "keyin":null,
             "title":null

         },{
            "ctrl":"input",
            "id":"listref",
            "label":"JR Detail",
            "type":"listform",
            "minlen":1,
            "maxlen":0,
            "keyin":"stock",
            "title":"Please scan or key in item",
            "autoadd":1,"form":{
               "title":"Enter Roll Weight Detail",
               "layout":[
                  {
                     "ctrl":"input",
                     "id":"roll_no",
                     "label":"Roll No",
                     "type":"number",
                     "minlen":1,
                     "maxlen":255,
                     "keyin":null,
                     "title":null
                  },
                  {
                     "ctrl":"input",
                     "id":"roll_weight",
                     "label":"Roll Weight",
                     "type":"number",
                     "minlen":1,
                     "maxlen":255,
                     "keyin":null,
                     "title":null
                  }
               ]
            }}
      ]
   }
}';

    SET @holder = '{
   "id":"jr_receive",
   "form":{
      "title":"Jumbo Roll Details",
      "layout":[
         {
            "ctrl":"input",
            "id":"po_no",
            "label":"PO No",
            "type":"lbox",
            "dsrc":"6,1,PO.TXT",
            "nline":3
         },
         {
            "ctrl":"input",
            "id":"invoice_no",
            "label":"Invoice Number",
            "type":"string",
            "minlen":1,
            "maxlen":255,
            "keyin":null,
            "title":null
         },{
            "ctrl":"input",
            "id":"container_no",
            "label":"Container No",
            "type":"string",
            "minlen":1,
            "maxlen":255,
            "keyin":null,
            "title":null
         },
         {
            "ctrl":"input",
            "id":"stock_no",
            "label":"Stock Code",
            "type":"lbox",
            "def":{
               "t":"N/A",
               "k":"-1"
            },
            "dsrc":"6,1,CSSTOCK.TXT",
            "nline":3
         },
         {
            "ctrl":"input",
            "id":"rolls_cnt",
            "label":"No. of Rolls",
            "type":"number",
            "minlen":1,
             "maxlen":255,
             "keyin":null,
             "title":null
         },
         {
            "ctrl":"input",
            "id":"total_weight",
            "label":"Total Weight",
            "type":"number",
            "minlen":1,
             "maxlen":255,
             "keyin":null,
             "title":null

         },
         {
            "ctrl":"input",
            "id":"listref",
            "label":"JR Detail",
            "type":"listform",
            "minlen":1,
            "maxlen":0,
            "keyin":"stock",
            "title":"Please scan or key in item",
            "autoadd":1,
            "form":{
               "title":"Scan, key in or select from list",
               "layout":[
                  {
                     "ctrl":"input",
                     "id":"roll_no",
                     "label":"Roll No",
                     "type":"number",
                     "minlen":1,
                     "maxlen":255,
                     "keyin":null,
                     "title":null
                  },
                  {
                     "ctrl":"input",
                     "id":"roll_weight",
                     "label":"Roll Weight",
                     "type":"number",
                     "minlen":1,
                     "maxlen":255,
                     "keyin":null,
                     "title":null
                  }
               ]
            }
         }
      ]
   }
}';

    SET  file_data = trim(replace(replace(file_data, '
',''),'   ',''));

    SET @fd_data = CONCAT(
        'T=', hex(@file_type), CHAR(10),
        'I=', hex(@file_id), CHAR(10),
        'R=1', CHAR(10),
        'L=', @file_name, CHAR(10),
        'M=1', CHAR(10),
        @otherheaders,
        'D=', CHAR(10),
        COALESCE(file_data, ''), CHAR(10));

    SET @datalength = LENGTH(@fd_data);

    SET output = CONCAT('B=', @datalength, CHAR(10), @fd_data);


    RETURN output;
  END;

