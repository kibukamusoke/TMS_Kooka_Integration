create procedure sp_buildAllFiles(IN `_tmn_hw_id` bigint, OUT output longtext)
  proc: BEGIN

  SET SESSION GROUP_CONCAT_MAX_LEN = 2000000000;
    SELECT (CONCAT(
              fn_buildContainerFile(),
              fn_buildTerminalStepTemplateJrReceive(),
              fn_buildTerminalStepTemplateJrTransfer(),
              fn_buildContainerFileForGF(),
              fn_buildBranchFileForGF(),
              fn_buildStockFileForGF(),
              fn_buildPOFileForGF(),
              fn_buildPOStockFileForGF(),
              fn_buildPOFile(),
              fn_buildRollsFileForGF()
        )) INTO output;


  end;

