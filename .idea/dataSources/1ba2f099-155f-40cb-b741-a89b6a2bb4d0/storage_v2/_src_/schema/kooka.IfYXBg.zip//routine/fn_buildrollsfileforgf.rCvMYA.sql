create function fn_buildRollsFileForGF()
  returns longtext
  BEGIN
    DECLARE output LONGTEXT;


    DECLARE file_data LONGTEXT DEFAULT '';

    SET SESSION group_concat_max_len = 20000000000;
    SET @file_type = 6;
    SET @file_name = 'CSROLLS.TXT';
    SET @file_id = 1;

    SET @otherheaders = CONCAT('O_EN=Select Container' ,CHAR(10),
                               'SEARCH_COL=2;6,1,CSROLLS.TXT;2,1',CHAR(10),
                               'COL_DESC=2',CHAR(10),
                               'COL_CODE=2',CHAR(10),
                               'COL_IDX=1',CHAR(10),
                               'SCHEMA_COL=,,stock_code.t,container_no.t', CHAR(10),
                               'SCHEMA_INDEXED_COL=3,4', CHAR(10));

    SET file_data = '';

    SELECT CONCAT(file_data, GROUP_CONCAT(rex SEPARATOR '
'), CHAR(10)) INTO file_data
    FROM (SELECT concat(id, '|', rollno, ' (', weight, ' KGs)|', itemcode, '|', container_do, '|') as rex
          FROM k_storeink
          WHERE status = 1
          GROUP BY itemcode, container_do
         ORDER BY itemcode ASC, container_do ASC, rollno ASC
         ) X;

    SET @fd_data = CONCAT(
        'T=', hex(@file_type), CHAR(10),
        'I=', hex(@file_id), CHAR(10),
        'R=1', CHAR(10),
        'L=', @file_name, CHAR(10),
        'M=1', CHAR(10),
        @otherheaders,
        'D=', CHAR(10),
        COALESCE(file_data, ''));

    SET @datalength = LENGTH(@fd_data);

    SET output = CONCAT('B=', @datalength, CHAR(10), @fd_data);


    RETURN output;
  END;

