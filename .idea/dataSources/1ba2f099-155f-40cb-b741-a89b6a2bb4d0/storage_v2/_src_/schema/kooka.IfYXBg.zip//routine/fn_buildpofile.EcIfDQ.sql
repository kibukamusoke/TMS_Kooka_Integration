create function fn_buildPOFile()
  returns longtext
  BEGIN
    DECLARE output LONGTEXT;


    DECLARE file_data LONGTEXT DEFAULT '';

    SET @file_type = 7;
    SET @file_name = 'PO.LST';
    SET @file_id = 1;

    SET @otherheaders = CONCAT('O_EN=Select PO' ,CHAR(10));


    SET file_data = '';

    SELECT CONCAT(file_data, GROUP_CONCAT(rex SEPARATOR '
'), CHAR(10)) INTO file_data
    FROM (SELECT concat(id, '|', pono, '|', tmn_ref, '|0|') as rex
          FROM k_po

          GROUP BY pono
          ORDER BY pono ASC) X;

    SET @fd_data = CONCAT(
        'T=', hex(@file_type), CHAR(10),
        'I=', hex(@file_id), CHAR(10),
        'R=1', CHAR(10),
        'L=', @file_name, CHAR(10),
        'M=1', CHAR(10),
        @otherheaders,
        'D=', CHAR(10),
        COALESCE(file_data, ''));

    SET @datalength = LENGTH(@fd_data);

    SET output = CONCAT('B=', @datalength, CHAR(10), @fd_data);


    RETURN output;
  END;

