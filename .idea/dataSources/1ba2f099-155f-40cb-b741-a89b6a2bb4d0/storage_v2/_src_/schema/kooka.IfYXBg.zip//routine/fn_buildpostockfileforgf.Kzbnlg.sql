create function fn_buildPOStockFileForGF()
  returns text
  BEGIN
    DECLARE output TEXT DEFAULT '';


    DECLARE file_data TEXT DEFAULT '';
    DECLARE done INT DEFAULT FALSE;
    DECLARE _id BIGINT;
    DECLARE _tmn_ref BIGINT;
    DECLARE _pono VARCHAR(100);
    DECLARE _file_id BIGINT;
    DECLARE _otherheaders TEXT;
    DECLARE _cursor CURSOR FOR SELECT tmn_ref, pono FROM k_po GROUP BY pono ORDER BY pono ASC;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    SET @file_type = 6;
    SET @file_name = 'CSSTOCK.TXT';
    SET @sess_id = hex(CEILING(RAND() * 1000000));

    OPEN _cursor;
    _loop: LOOP
      FETCH _cursor
      INTO _tmn_ref, _pono;

      IF done THEN
        LEAVE _loop;
      END IF;

      SET _otherheaders = CONCAT('O_EN=select or scan stock code' ,CHAR(10) ,
                                 'SEARCH_COL=3;6,',_tmn_ref,',CSSTOCK.TXT;2,1' , CHAR(10) ,
                                 'COL1IDX=6,',_tmn_ref,',CSSTOCK.X1' , CHAR(10) ,
                                 'COL2IDX=6,',_tmn_ref,',CSSTOCK.TXT;X2' , CHAR(10) ,
                                 'COL3IDX=6,',_tmn_ref,',CSSTOCK.X3' , CHAR(10),
                                 'COL_DESC=2' , CHAR(10) ,
                                 'COL_CODE=3' , CHAR(10) ,
                                 'COL_IDX=1' , CHAR(10) ,
                                 'COL_MAINFILE_LINENUM=4' , CHAR(10) ,
                                 'COL_SORTED_LINENUM=4' , CHAR(10) ,
                                 'IDX_SESS_ID=' , @sess_id , CHAR(10));

      SET file_data = '';
      SELECT CONCAT(file_data, GROUP_CONCAT(rex SEPARATOR '
'), CHAR(10)) INTO file_data
      FROM (SELECT concat(id, '|', COALESCE(itemcode,''), '|', COALESCE(itemcode,''), '|', id, '|') as rex
            FROM k_podetail
            WHERE pono = _pono
            GROUP BY itemcode
            ORDER BY itemcode ASC) X;

      SET @fd_data = CONCAT(
          'T=', hex(@file_type), CHAR(10),
          'I=', hex(_tmn_ref), CHAR(10),
          'R=1', CHAR(10),
          'L=', @file_name, CHAR(10),
          'M=1', CHAR(10),
          _otherheaders,
          'D=', CHAR(10),
          COALESCE(file_data, ''));

      SET @datalength = LENGTH(@fd_data);

      SET output = CONCAT(output, 'B=', @datalength, CHAR(10), @fd_data);




    END loop;
    CLOSE _cursor;

    RETURN output;
  END;

