create function fn_buildTerminalStepTemplateJrTransfer()
  returns text
  BEGIN
    DECLARE output TEXT;


    DECLARE file_data TEXT DEFAULT '';

    SET @file_type = 7;
    SET @file_name = 'FORMX.DAT';
    SET @file_id = 2;

    SET @otherheaders = '';


    SET file_data = '{
   "id":"jr_transfer",
   "form":{
      "title":"Jumbo Roll Details",
      "layout":[
         {
            "ctrl":"input",
            "id":"doc_no",
            "label":"Document Number",
            "type":"string",
            "minlen":1,
            "maxlen":255,
            "keyin":null,
            "title":null
         },{
            "ctrl":"input",
            "id":"branch_id",
            "label":"Branch",
            "type":"lbox",
            "dsrc":"6,1,BRANCH.TXT",
            "nline":3
         },
         {
            "ctrl":"input",
            "id":"listref",
            "label":"JR Detail",
            "type":"listform",
            "minlen":1,
            "maxlen":0,
            "keyin":"stock",
            "title":"Please scan or key in item",
            "autoadd":1,
            "form":{
               "title":"Scan, key in or select from list",
               "layout":[
                  {
                    "ctrl":"input",
                    "id":"stock_code",
                    "label":"Stock Code",
                    "type":"lbox",
                    "def":{
                       "t":"N/A",
                       "k":"-1"
                    },
                    "dsrc":"6,1,CSSTOCK.TXT",
                    "nline":3
                 },{
                    "ctrl":"input",
                    "id":"container_no",
                    "label":"Container Number",
                    "type":"lbox",
                    "def":{
                       "t":"N/A",
                       "k":"-1"
                    },
                    "dsrc":"6,1,CSSTORE.TXT",
                    "nline":3
                 },{
                     "ctrl":"input",
                     "id":"roll_no",
                     "label":"Roll No",
                     "type":"number",
                     "minlen":1,
                     "maxlen":255,
                     "keyin":null,
                     "title":null
                  },
                  {
                     "ctrl":"input",
                     "id":"roll_weight",
                     "label":"Roll Weight",
                     "type":"number",
                     "minlen":1,
                     "maxlen":255,
                     "keyin":null,
                     "title":null
                  }
               ]
            }
         }
      ]
   }
}';

    

    SET @fd_data = CONCAT(
        'T=', hex(@file_type), CHAR(10),
        'I=', hex(@file_id), CHAR(10),
        'R=1', CHAR(10),
        'L=', @file_name, CHAR(10),
        'M=1', CHAR(10),
        @otherheaders,
        'D=', CHAR(10),
        COALESCE(file_data, ''));

    SET @datalength = LENGTH(@fd_data);

    SET output = CONCAT('B=', @datalength, CHAR(10), @fd_data);


    RETURN output;
  END;

