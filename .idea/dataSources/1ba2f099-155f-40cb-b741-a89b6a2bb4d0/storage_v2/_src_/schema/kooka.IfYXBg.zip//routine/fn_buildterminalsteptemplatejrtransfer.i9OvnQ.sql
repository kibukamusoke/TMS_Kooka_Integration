create function fn_buildTerminalStepTemplateJrTransfer()
  returns text
  BEGIN
    DECLARE output TEXT;


    DECLARE file_data TEXT DEFAULT '';

    SET @file_type = 7;
    SET @file_name = 'JRTRF.DAT';
    SET @file_id = 1;

    SET @otherheaders = '';


    SET file_data = '{
   "id":"jr_transfer",
   "form":{
      "title":"Jumbo Roll Details",
      "layout":[
         {
            "ctrl":"input",
            "id":"doc_no",
            "label":"Document Number",
            "type":"string",
            "minlen":1,
            "maxlen":255,
            "keyin":null,
            "title":null
         },{
            "ctrl":"input",
            "id":"branch_id",
            "label":"Branch",
            "type":"lbox",
            "dsrc":"6,1,BRANCH.TXT",
            "nline":3
         },
         {
            "ctrl":"input",
            "id":"listref",
            "label":"JR Detail",
            "type":"listform",
            "minlen":1,
            "maxlen":0,
            "keyin":"stock_code",
            "title":"Please scan or key in item",
            "form":{
               "title":"Scan, key in or select from list",
               "layout":[
                  {
                    "ctrl":"input",
                    "id":"stock_code",
                    "label":"Stock Code",
                    "type":"lbox",
                    "def":{
                       "t":"N/A",
                       "k":"-1"
                    },
                    "dsrc":"6,-1,CSSTOCK.TXT",
                    "nline":3
                 },{
                    "ctrl":"input",
                    "id":"container_no",
                    "label":"Container Number",
                    "type":"lbox",
                    "def":{
                       "t":"N/A",
                       "k":"-1"
                    },
                    "dsrc":"6,1,CSSTORE.TXT",
                    "filt":"stock_code.t",
                    "nline":3
                 },{
                    "ctrl":"input",
                    "id":"roll_no",
                    "label":"Roll Number",
                    "type":"lbox",
                    "def":{
                       "t":"N/A",
                       "k":"-1"
                    },
                    "dsrc":"6,1,CSROLLS.TXT",
                    "filt":"stock_code.t&&container_no.t",
                    "nline":3
                 }
               ]
            }
         }
      ]
   }
}';

    SET  file_data = trim(replace(replace(file_data, '
',''),'   ',''));

    SET @fd_data = CONCAT(
        'T=', hex(@file_type), CHAR(10),
        'I=', hex(@file_id), CHAR(10),
        'R=1', CHAR(10),
        'L=', @file_name, CHAR(10),
        'M=1', CHAR(10),
        @otherheaders,
        'D=', CHAR(10),
        COALESCE(file_data, ''),CHAR(10));

    SET @datalength = LENGTH(@fd_data);

    SET output = CONCAT('B=', @datalength, CHAR(10), @fd_data);


    RETURN output;
  END;

