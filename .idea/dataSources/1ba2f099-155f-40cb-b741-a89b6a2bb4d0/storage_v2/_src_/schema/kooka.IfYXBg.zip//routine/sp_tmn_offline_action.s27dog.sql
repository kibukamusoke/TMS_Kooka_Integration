create procedure sp_tmn_offline_action(IN `_data` longtext, IN action varchar(100), OUT output text)
  proc: BEGIN
    DECLARE cardno VARCHAR(20);
    DECLARE version VARCHAR(20);
    DECLARE ip_address VARCHAR(30);
    DECLARE txndate DATETIME;
    DECLARE tmntxnid BIGINT;
    DECLARE p1 TEXT;
    DECLARE p54 TEXT;
    DECLARE p128 JSON;
    DECLARE seq BIGINT;
    DECLARE _action_id BIGINT;
    DECLARE _tmn_hw_id BIGINT;

    DECLARE _staff_id BIGINT;
    DECLARE _staff_name VARCHAR(200);
    DECLARE _po_id BIGINT;
    DECLARE _pono VARCHAR(200);
    DECLARE _supplier_code VARCHAR(200);
    DECLARE _supplier_name VARCHAR(200);
    DECLARE _container_no VARCHAR(50);
    DECLARE _invoice_no VARCHAR(50);
    DECLARE _current_item BLOB;
    DECLARE _i INT UNSIGNED DEFAULT 0;
    DECLARE _cnt INT UNSIGNED DEFAULT NULL;

    SET group_concat_max_len = 20000000;

    SET cardno = JSON_UNQUOTE(JSON_EXTRACT(_data, "$.cardno"));
    SET version = JSON_UNQUOTE(JSON_EXTRACT(_data, "$.v"));
    SET txndate = JSON_UNQUOTE(JSON_EXTRACT(_data, "$.txndate"));
    SET seq = JSON_UNQUOTE(JSON_EXTRACT(_data, "$.seq"));
    SET _action_id = JSON_UNQUOTE(JSON_EXTRACT(_data, "$.act"));
    SET p128 = JSON_UNQUOTE(JSON_EXTRACT(_data, "$.p128"));
    SET _po_id = JSON_UNQUOTE(JSON_EXTRACT(_data, "$.p54"));

    IF (action = 'jr_receive') THEN
      SET p128 = JSON_UNQUOTE(JSON_EXTRACT(p128, "$.jr_receive"));
      SET _container_no = JSON_UNQUOTE(JSON_EXTRACT(p128, "$.container_no"));
      SET _invoice_no = JSON_UNQUOTE(JSON_EXTRACT(p128, "$.invoice_no"));
      SET @stock_id = JSON_UNQUOTE(JSON_EXTRACT(JSON_UNQUOTE(JSON_EXTRACT(p128, "$.stock_no")), "$.k"));
      SET @stock_code = JSON_UNQUOTE(JSON_EXTRACT(JSON_UNQUOTE(JSON_EXTRACT(p128, "$.stock_no")), "$.c"));
      SET @stock_name = JSON_UNQUOTE(JSON_EXTRACT(JSON_UNQUOTE(JSON_EXTRACT(p128, "$.stock_no")), "$.t"));
      SET @total_rolls = JSON_UNQUOTE(JSON_EXTRACT(p128, "$.rolls_cnt"));
      SET @total_weight = JSON_UNQUOTE(JSON_EXTRACT(p128, "$.total_weight"));
      SET @roll_detail = JSON_EXTRACT(p128, "$.listref");

      SELECT creditorname, creditorcode, pono
      INTO _supplier_name, _supplier_code, _pono
      FROM k_po
      WHERE id =_po_id;

      INSERT INTO k_unloadingchecklist (suppliername, code_supplier, pono, itemcode, containerno, total_weight, total_rolls, unloading_date, invno, status, branch)
      VALUES (_supplier_name, _supplier_code, _pono, @stock_code, _container_no, @total_weight, @total_rolls,txndate, _invoice_no, 2, _tmn_hw_id);

      SET @idx = LAST_INSERT_ID();
      -- iterate over the rolls detail array
      SET _i = 0;
      SET _cnt = JSON_LENGTH(@roll_detail);
    -- loop from 0 to the last item
      WHILE _i < _cnt DO
        SET _current_item :=
        JSON_EXTRACT(@roll_detail, CONCAT('$[', _i, ']'));
        -- insert detail ::
        INSERT INTO k_unloadingdetail (checkid, pono, itemcode, containerno, rollno, invno, weight, unloading_date, branch)
        VALUES (@idx, _pono, @stock_code, _container_no, JSON_UNQUOTE(JSON_EXTRACT(_current_item, "$.roll_no")), _invoice_no, JSON_UNQUOTE(JSON_EXTRACT(_current_item, "$.roll_weight")), JSON_UNQUOTE(JSON_EXTRACT(_current_item, "$._dt_")), _tmn_hw_id);
        SET _i := _i + 1;
      END WHILE;
      SET output = fn_formulate_outputstring('2', 'SUCCESS', 'JR Receive logged', '', '', '');
    end if;


  end;

