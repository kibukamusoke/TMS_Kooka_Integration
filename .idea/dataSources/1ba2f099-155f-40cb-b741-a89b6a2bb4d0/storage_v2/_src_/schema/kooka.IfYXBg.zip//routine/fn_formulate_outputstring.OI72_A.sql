create function fn_formulate_outputstring(buzzer    varchar(10), lcd_line1 varchar(300), lcd_line2 varchar(300),
                                          lcd_line3 varchar(300), lcd_line4 varchar(300), printer varchar(4096))
  returns varchar(4000)
  BEGIN
    DECLARE B VARCHAR(10);
    DECLARE ret VARCHAR(4096);
    SET ret = '';

    IF buzzer = '3'
    THEN
      SET buzzer = 'A';
      SET B = 'B`';
    ELSE IF buzzer = '1'
    THEN
      SET B = '';
      SET buzzer = 'A';

    ELSE
      SET buzzer = 'E';
      SET B = 'B`';
    END IF;

      SET ret = CONCAT(ret, '{', B, buzzer, '`}');
      SET lcd_line1 = RTRIM(lcd_line1);
      SET lcd_line2 = RTRIM(lcd_line2);
      SET lcd_line3 = RTRIM(lcd_line3);
      SET lcd_line4 = RTRIM(lcd_line4);
      IF LENGTH(lcd_line1) > 0 OR LENGTH(lcd_line2) > 0 OR LENGTH(lcd_line3) > 0 OR LENGTH(lcd_line4) > 0
      THEN
        SET ret = CONCAT(ret, '{L`');
        IF LENGTH(lcd_line1) > 0
        THEN
          SET ret = CONCAT(ret, '[1`', lcd_line1, '`]');
        END IF;

        IF LENGTH(lcd_line2) > 0
        THEN
          SET ret = CONCAT(ret, '[2`', lcd_line2, '`]');
        END IF;
        IF LENGTH(lcd_line3) > 0
        THEN
          SET ret = CONCAT(ret, '[3`', lcd_line3, '`]');
        END IF;
        IF LENGTH(lcd_line4) > 0
        THEN
          SET ret = CONCAT(ret, '[4`', lcd_line4, '`]');
        END IF;
        SET ret = CONCAT(ret, '`}');
      END IF;

      SET printer = LTRIM(RTRIM(printer));

      IF LENGTH(printer) > 10
      THEN
        SET ret = CONCAT(ret, '{P`', '[T`', printer, '`]`}');
      END IF;

    END IF;

    RETURN ret;


  END;

